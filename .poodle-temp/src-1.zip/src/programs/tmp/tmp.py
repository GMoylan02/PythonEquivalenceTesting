array = (1, 2, 3, 4, 5, 6, 7, 8, 9, 10)
length = 10

lo = 0
hi = length
found = False


def get(n):
    a0, a1, a2, a3, a4, a5, a6, a7, a8, a9 = array
    if n == 0: return a0
    elif n == 1: return a1
    elif n == 2: return a2
    elif n == 3: return a3
    elif n == 4: return a4
    elif n == 5: return a5
    elif n == 6: return a6
    elif n == 7: return a7
    elif n == 8: return a8
    elif n == 9: return a9
    else: return -1


def bsearch(key):
    global lo, hi, found

    if lo + 1 < hi:
        mid = (lo + hi) // 2

        if get(mid) <= key:
            lo = mid + 1
        else:
            hi = mid

        return bsearch(key)
    else:
        found = (get(lo) == key)
        return found

